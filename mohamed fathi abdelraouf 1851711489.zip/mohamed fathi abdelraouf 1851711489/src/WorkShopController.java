
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author MBR
 */
public class WorkShopController {

    @FXML
    private Button del;
    
    @FXML
    private TableColumn<WorkShop, String> workname;

    @FXML
    private TableView<WorkShop> tableWork;

    @FXML
    private TableColumn<Attendee, String> namePer;

    @FXML
    private TableView<Attendee> persons;

    @FXML
    private TableColumn<Attendee, String> number;
    @FXML
    private TableColumn<Attendee, Integer> id;

    @FXML
    private TableColumn<Attendee, String> age;

    @FXML
    private TextField namea;

    @FXML
    private TextField ida;

    @FXML
    private TextField agea;

    @FXML
    private TextField deID;

    @FXML
    private TextField numbera;

    @FXML
    private Button btnDo;

    private List<Attendee> l = new ArrayList<>();

    @FXML
    void show(ActionEvent event) {

        workname.setCellValueFactory(
                new PropertyValueFactory<WorkShop, String>("name")
        );
        id.setCellValueFactory(
                new PropertyValueFactory<Attendee, Integer>("passportNumber")
        );
        namePer.setCellValueFactory(
                new PropertyValueFactory<Attendee, String>("fullName")
        );
        number.setCellValueFactory(
                new PropertyValueFactory<Attendee, String>("number")
        );
        age.setCellValueFactory(
                new PropertyValueFactory<Attendee, String>("age")
        );
        tableWork.setItems(getObs());
        persons.setItems(getAtt());
        tableWork.setVisible(false);
        persons.setVisible(false);
        ida.setVisible(false);
        namea.setVisible(false);
        numbera.setVisible(false);
        agea.setVisible(false);
        agea.setVisible(false);
        btnDo.setVisible(false);
        deID.setVisible(false);
        btnDo.setVisible(false);
        del.setVisible(false);
        tableWork.setVisible(true);
        persons.setVisible(true);
    }

    public ObservableList<WorkShop> getObs() {
        AttendeeController getWorkShops = new AttendeeController();
        List<String> works = getWorkShops.getWorkShops();
        List<WorkShop> l = new ArrayList<>();
        for (int i = 0; i < works.size(); i++) {
            l.add(new WorkShop(works.get(i)));
        }
        ObservableList<WorkShop> w = FXCollections.observableArrayList(
                l
        );
        return w;
    }

    public ObservableList<Attendee> getAtt() {
        AttendeeController getWorkShops = new AttendeeController();
        List<WorkShop> works = getWorkShops.showAllAppendables();

        for (int i = 0; i < works.size(); i++) {
            l.addAll(works.get(i).getAppendables());
        }
        ObservableList<Attendee> w = FXCollections.observableArrayList(
                l
        );
        return w;
    }

    @FXML
    void doDelete(ActionEvent event) {
        int id = Integer.parseInt(deID.getText());
        for(int i=0;i<l.size();i++){
            if(l.get(i).getPassportNumber() == id){
                l.remove(l.get(i));
            }
        }
    }

    @FXML
    void add(ActionEvent event) {

       tableWork.setVisible(false);
        persons.setVisible(false);
        ida.setVisible(false);
        namea.setVisible(false);
        numbera.setVisible(false);
        agea.setVisible(false);
        agea.setVisible(false);
        btnDo.setVisible(false);
        deID.setVisible(false);
        btnDo.setVisible(false);
        agea.setVisible(true);
        btnDo.setVisible(true);
        ida.setVisible(true);
        namea.setVisible(true);
        numbera.setVisible(true);
        
    }

    @FXML
    void delete(ActionEvent event) {
        tableWork.setVisible(false);
        persons.setVisible(false);
        ida.setVisible(false);
        namea.setVisible(false);
        numbera.setVisible(false);
        agea.setVisible(false);
        agea.setVisible(false);
        btnDo.setVisible(false);
        deID.setVisible(false);
        btnDo.setVisible(false);
        deID.setVisible(true);
        del.setVisible(true);
    }

    @FXML
    void clear(ActionEvent event) {
        ida.setText("");
        namea.setText("");
        numbera.setText("");
        agea.setText("");
        deID.setText("");
    }

    @FXML
    void initialize() {
        tableWork.setVisible(false);
        persons.setVisible(false);
        ida.setVisible(false);
        namea.setVisible(false);
        numbera.setVisible(false);
        agea.setVisible(false);
        agea.setVisible(false);
        btnDo.setVisible(false);
        deID.setVisible(false);
        btnDo.setVisible(false);
        del.setVisible(false);

    }

    @FXML
    void doneAdd(ActionEvent event) {
        System.out.println(namea.getText());
        l.add(new Attendee(Integer.parseInt(ida.getText()), namea.getText(), numbera.getText(), agea.getText()));
    }
    // 
}
