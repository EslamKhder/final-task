import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AttendeeController {

    private List<WorkShop> appendables = new ArrayList<>();
    private List<String> namsWorkShop = new ArrayList<>();
    private List<Long> ids = new ArrayList<>();
    

    public AttendeeController() {
    }

    public List<String> getWorkShops() {

        try {
            File myObj = new File("workshop.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                namsWorkShop.add(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return namsWorkShop;
    }
    
    public List<WorkShop> showAllAppendables(){
        return appendables;
    }

    public void addAttendee(WorkShop workShop) {
        int flag = 0;
        for (int i = 0; i < workShop.getAppendables().size(); i++) {
            if(!ids.contains(workShop.getAppendables().get(i).getPassportNumber())){
                ids.add(workShop.getAppendables().get(i).getPassportNumber());                
                flag = 1;
            } else {
                flag = 0;
                break;
            }
        }
        
        if (flag == 0) {
            System.out.println("Pass Id Is Exist");
        } else {
            appendables.add(workShop);
        }
    }

    public void removeAttendee(Long id) {
        int flag = 0;
        for (int i = 0; i < appendables.size(); i++) {
            for (int z = 0; z < appendables.get(i).getAppendables().size(); z++) {
                Attendee attendee = appendables.get(i).getAppendables().get(z);

                if (attendee.getPassportNumber() == id) {
                    appendables.get(i).getAppendables().remove(attendee);
                    flag = 1;
                    break;
                }
            }
            if (flag == 1) {
                break;
            }
        }
        if(flag == 0){
            System.out.println("Pass Id Is Exist");
        }
    }

    public void diplayWorkShop() {
        for (int i = 0; i < appendables.size(); i++) {
            System.out.println(appendables.get(i).getName());
            for (int z = 0; z < appendables.get(i).getAppendables().size(); z++) {
                System.out.print("attendee " + (z + 1) + " ");
                System.out.print(appendables.get(i).getAppendables().get(z).getPassportNumber() + "  ");
                System.out.print(appendables.get(i).getAppendables().get(z).getFullName() + "  ");
                System.out.print(appendables.get(i).getAppendables().get(z).getNumber() + "  ");
                System.out.print(appendables.get(i).getAppendables().get(z).getAge() + "  ");
                System.out.println();
            }

        }
    }
}
