public class Attendee {

    private long passportNumber;
    private String fullName;
    private String number;
    private String age;
    
    public Attendee() {
    }

    public Attendee(long passportNumber, String fullName, String number, String age) {
        this.passportNumber = passportNumber;
        this.fullName = fullName;
        this.number = number;
        this.age = age;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
    

    public long getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(long passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
    
    
}
