import java.util.ArrayList;
import java.util.List;
public class WorkShop {
    
    private String name;
    
    private List<Attendee> appendables = new  ArrayList<>();

    
    
    public WorkShop() {
    }

    public WorkShop(String name) {
        this.name = name;
    }

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Attendee> getAppendables() {
        return appendables;
    }

    public void setAppendables(List<Attendee> appendables) {
        this.appendables = appendables;
    }
    
    
    
}
