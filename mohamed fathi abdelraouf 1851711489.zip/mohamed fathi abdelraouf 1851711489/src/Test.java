public class Test {

    public static void main(String[] args) {
        // TODO code application logic here
        WorkShop workShop1 = new WorkShop();
        workShop1.setName("WorkShop 1");
        WorkShop workShop2 = new WorkShop();
        workShop2.setName("WorkShop 2");
        Attendee attendee1 = new Attendee(1000, "Ahmed", "20", "20");
        workShop1.getAppendables().add(attendee1);
        Attendee attendee2 = new Attendee(1001, "Ayman", "30", "25");
        workShop1.getAppendables().add(attendee2);
        Attendee attendee3 = new Attendee(1002, "Ali", "40", "30");
        workShop1.getAppendables().add(attendee3);
        Attendee attendee4 = new Attendee(1003, "Atef", "45", "25");
        workShop2.getAppendables().add(attendee4);
        Attendee attendee5 = new Attendee(1004, "Samir", "35", "40");
        workShop2.getAppendables().add(attendee5);
        AttendeeController ac = new AttendeeController();
        
        Attendee attendee6 = new Attendee(1005, "Samir", "35", "40");
        workShop2.getAppendables().add(attendee6);
        ac.addAttendee(workShop1);
        ac.addAttendee(workShop2);
        ac.diplayWorkShop();
        long id = 1006;
        ac.removeAttendee(id);
    }
    
}
